x=12
y=7
z=8
if(x>y and x>z):
    print(x,'is greater')
elif(y>x and y>z):
    print(y,'is greater')
else:
    print(z,'is greater')
