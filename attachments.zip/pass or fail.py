a=36
if(a>35):
    print('pass')
else:
    print('fail')
