a=3
b=6
c=a+b
if(c>5):
    print('c is greater than 5')
elif(c==5):
    print('equal')
else:
    print('c is lesser than 5')
